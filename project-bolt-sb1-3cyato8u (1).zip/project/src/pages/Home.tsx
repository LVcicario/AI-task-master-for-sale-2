import React from 'react';
import { Link } from 'react-router-dom';
import { useState } from 'react';
import { 
  Zap, 
  Users, 
  BarChart3, 
  ArrowRight, 
  CheckCircle, 
  Star,
  Play,
  Mail,
  Award,
  TrendingUp,
  Shield,
  Clock,
  Globe,
  Sparkles
} from 'lucide-react';
import { subscribeToNewsletter } from '../lib/supabase';

const Home = () => {
  const [email, setEmail] = useState('');
  const [subscribing, setSubscribing] = useState(false);
  const [subscribed, setSubscribed] = useState(false);

  const stats = [
    { number: '50,000+', label: 'Active Teams', icon: <Users className="w-5 h-5" /> },
    { number: '40%', label: 'Time Saved', icon: <Clock className="w-5 h-5" /> },
    { number: '99.9%', label: 'Uptime SLA', icon: <Shield className="w-5 h-5" /> },
    { number: '150+', label: 'Countries', icon: <Globe className="w-5 h-5" /> }
  ];

  const features = [
    {
      icon: <Zap className="w-8 h-8 text-blue-600" />,
      title: 'AI Auto-Assignment 2.0',
      description: 'Revolutionary AI that learns your team\'s patterns and automatically assigns tasks for maximum efficiency.',
      benefits: ['40% faster task completion', 'Smart workload balancing', 'Skill-based matching']
    },
    {
      icon: <Users className="w-8 h-8 text-blue-600" />,
      title: 'Real-Time Collaboration',
      description: 'Connect your global team with instant updates, live editing, and seamless communication.',
      benefits: ['Live document editing', 'Instant notifications', 'Video call integration']
    },
    {
      icon: <BarChart3 className="w-8 h-8 text-blue-600" />,
      title: 'Predictive Analytics',
      description: 'AI-powered insights that predict bottlenecks and optimize your team\'s performance.',
      benefits: ['Performance forecasting', 'Bottleneck detection', 'ROI tracking']
    }
  ];

  const socialProof = [
    { logo: 'Microsoft', employees: '100,000+' },
    { logo: 'Shopify', employees: '10,000+' },
    { logo: 'Airbnb', employees: '6,000+' },
    { logo: 'Spotify', employees: '8,000+' },
    { logo: 'Uber', employees: '29,000+' },
    { logo: 'Netflix', employees: '11,000+' }
  ];

  const benefits = [
    {
      icon: <TrendingUp className="w-6 h-6 text-green-600" />,
      title: 'Boost Productivity by 40%',
      description: 'Teams using AI TaskMaster complete projects 40% faster on average'
    },
    {
      icon: <Award className="w-6 h-6 text-purple-600" />,
      title: 'Award-Winning Platform',
      description: 'Recognized as "Best AI Tool 2024" by TechCrunch and ProductHunt'
    },
    {
      icon: <Sparkles className="w-6 h-6 text-yellow-600" />,
      title: 'Loved by Teams Worldwide',
      description: '4.9/5 rating from 50,000+ teams across 150+ countries'
    }
  ];

  const testimonials = [
    {
      name: 'Sarah Johnson',
      role: 'Directrice Produit chez TechCorp',
      content: 'AI TaskMaster a complètement transformé le fonctionnement de notre équipe distante. L\'assignation automatique par IA, c\'est comme avoir un chef de projet super-intelligent qui ne dort jamais. Nous avons vu une augmentation de 45% de productivité et le stress de l\'équipe a considérablement diminué.',
      rating: 5,
      company: 'TechCorp',
      avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop'
    },
    {
      name: 'Michael Chen',
      role: 'CTO chez StartupXYZ',
      content: 'En tant que CTO gérant plusieurs équipes de développement, AI TaskMaster a été révolutionnaire. Les analyses prédictives nous aident à identifier les goulots d\'étranglement avant qu\'ils ne deviennent des problèmes. Notre taux de completion des sprints s\'est amélioré de 60%.',
      rating: 5,
      company: 'StartupXYZ',
      avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop'
    },
    {
      name: 'Emily Rodriguez',
      role: 'Chef d\'Équipe chez DesignStudio',
      content: 'Nous avons essayé tous les outils de gestion de tâches existants, mais rien ne se rapproche d\'AI TaskMaster. Les fonctionnalités de collaboration en temps réel maintiennent notre équipe créative parfaitement synchronisée, et les analyses fournissent des insights que nous n\'avions jamais eus auparavant.',
      rating: 5,
      company: 'DesignStudio',
      avatar: 'https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop'
    },
    {
      name: 'David Kim',
      role: 'Directeur Opérations chez GlobalTech',
      content: 'Gérer plus de 200 membres d\'équipe dans 15 pays était un cauchemar jusqu\'à ce que nous trouvions AI TaskMaster. L\'IA gère la distribution des tâches parfaitement, et notre temps de livraison de projet s\'est amélioré de 35%.',
      rating: 5,
      company: 'GlobalTech',
      avatar: 'https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop'
    },
    {
      name: 'Lisa Thompson',
      role: 'VP Ingénierie chez InnovateCorp',
      content: 'Le ROI a été immédiat. Dès le premier mois, nous avons économisé plus de 200 heures de gestion manuelle des tâches. L\'IA apprend les préférences de notre équipe et devient plus intelligente chaque jour.',
      rating: 5,
      company: 'InnovateCorp',
      avatar: 'https://images.pexels.com/photos/1181424/pexels-photo-1181424.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop'
    },
    {
      name: 'James Wilson',
      role: 'Fondateur chez AgileStartup',
      content: 'AI TaskMaster a évolué avec nous de 5 à 50 employés. Les fonctionnalités entreprise sont robustes, et l\'équipe support est incroyablement réactive. C\'est un outil essentiel pour toute entreprise en croissance.',
      rating: 5,
      company: 'AgileStartup',
      avatar: 'https://images.pexels.com/photos/1212984/pexels-photo-1212984.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop'
    }
  ];

  const handleNewsletterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubscribing(true);

    try {
      const { error } = await subscribeToNewsletter(email);
      if (error) throw error;
      
      setSubscribed(true);
      setEmail('');
      setTimeout(() => setSubscribed(false), 3000);
    } catch (error) {
      console.error('Newsletter subscription error:', error);
      alert('Failed to subscribe. Please try again.');
    } finally {
      setSubscribing(false);
    }
  };

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-50 via-white to-purple-50 py-16 md:py-24 relative overflow-hidden animate-fade-in-up">
        {/* Background Elements */}
        <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>
        <div className="absolute top-20 left-10 w-72 h-72 bg-blue-200 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-blob"></div>
        <div className="absolute top-40 right-10 w-72 h-72 bg-purple-200 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-blob animation-delay-2000"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center relative z-10">
            {/* Trust Badge */}
            <div className="inline-flex items-center bg-blue-100 text-blue-800 px-4 py-2 rounded-full text-sm font-medium mb-6">
              <Award className="w-4 h-4 mr-2" />
              #1 Outil de Gestion de Tâches IA - TechCrunch 2024
            </div>
            
            <h1 className="text-4xl md:text-7xl font-bold text-gray-900 mb-8 leading-tight">
              Transformez la <br />
              <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">Productivité</span> de Votre Équipe avec l'IA
            </h1>
            <p className="text-xl md:text-2xl text-gray-600 mb-10 max-w-4xl mx-auto leading-relaxed">
              Rejoignez 50 000+ équipes utilisant AI TaskMaster pour <strong>économiser 40% de temps</strong> avec l'automatisation intelligente des tâches, 
              la collaboration en temps réel et les analyses prédictives. <span className="text-blue-600 font-semibold">Commencez gratuitement aujourd'hui!</span>
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12 animate-slide-in-left">
              <Link
                to="/pricing"
                className="bg-gradient-to-r from-blue-600 to-blue-700 text-white px-10 py-4 rounded-xl text-lg font-bold hover:from-blue-700 hover:to-blue-800 transition-all duration-200 flex items-center gap-2 shadow-xl hover:shadow-2xl transform hover:-translate-y-1 hover-lift"
              >
                Essai Gratuit - Sans Carte Bancaire
                <ArrowRight className="w-5 h-5" />
              </Link>
              <Link
                to="/features"
                className="flex items-center gap-2 text-gray-700 hover:text-blue-600 transition-colors px-6 py-4 rounded-xl border-2 border-gray-200 hover:border-blue-300 bg-white hover:bg-blue-50 font-semibold hover-lift"
              >
                <Play className="w-5 h-5" />
                Voir la Démo 2 Min
              </Link>
            </div>
            
            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto animate-fade-in-up">
              {stats.map((stat, index) => (
                <div key={index} className="text-center bg-white/80 backdrop-blur-sm rounded-xl p-4 shadow-lg hover-lift will-change-transform">
                  <div className="flex items-center justify-center text-blue-600 mb-2">
                    {stat.icon}
                  </div>
                  <div className="text-2xl md:text-3xl font-bold text-gray-900 mb-1">{stat.number}</div>
                  <p className="text-gray-600 text-sm font-medium">{stat.label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Social Proof */}
      <section className="py-12 bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <p className="text-center text-gray-500 mb-8 font-medium">Approuvé par des équipes d'entreprises de classe mondiale</p>
          <div className="grid grid-cols-3 md:grid-cols-6 gap-8 items-center opacity-60">
            {socialProof.map((company, index) => (
              <div key={index} className="text-center hover-lift will-change-transform">
                <div className="text-2xl font-bold text-gray-400 mb-1">{company.logo}</div>
                <div className="text-xs text-gray-400">{company.employees} employees</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 bg-gradient-to-r from-green-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Pourquoi 50 000+ Équipes Choisissent AI TaskMaster
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Rejoignez la révolution de la productivité et voyez des résultats immédiats
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {benefits.map((benefit, index) => (
              <div key={index} className="text-center p-8 bg-white rounded-2xl shadow-lg hover:shadow-xl transition-shadow hover-lift will-change-transform">
                <div className="flex justify-center mb-4">
                  {benefit.icon}
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">{benefit.title}</h3>
                <p className="text-gray-600">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-bold text-gray-900 mb-6">
              Fonctionnalités IA Révolutionnaires Qui <span className="text-blue-600">Fonctionnent Vraiment</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Arrêtez de perdre du temps sur la gestion manuelle des tâches. Notre IA apprend les habitudes de votre équipe et optimise tout automatiquement.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="text-center p-8 rounded-2xl bg-gradient-to-br from-gray-50 to-white hover:from-blue-50 hover:to-blue-100 transition-all duration-300 border border-gray-100 hover:border-blue-200 shadow-lg hover:shadow-xl group hover-lift will-change-transform">
                <div className="flex justify-center mb-4">
                  {feature.icon}
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4 group-hover:text-blue-600 transition-colors">
                  {feature.title}
                </h3>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  {feature.description}
                </p>
                {feature.benefits && (
                  <ul className="text-sm text-gray-500 space-y-2">
                    {feature.benefits.map((benefit, i) => (
                      <li key={i} className="flex items-center justify-center">
                        <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                        {benefit}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Demo Video Section */}
      <section className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
            Voyez Comment AI TaskMaster Transforme Votre Flux de Travail
          </h2>
          <p className="text-xl text-gray-600 mb-8">Regardez comment les équipes économisent 40% de leur temps avec l'automatisation intelligente</p>
          <div className="bg-gradient-to-br from-gray-200 to-gray-300 rounded-2xl aspect-video flex items-center justify-center shadow-2xl hover:shadow-3xl transition-shadow cursor-pointer group hover-lift will-change-transform">
            <div className="text-center">
              <Play className="w-24 h-24 text-gray-600 mx-auto mb-4 group-hover:text-blue-600 transition-colors group-hover:scale-110 transform" />
              <p className="text-gray-600 text-xl font-semibold">▶ Regarder la Démo 2 Minutes</p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-bold text-gray-900 mb-6">
              Adoré par 50 000+ Équipes dans le Monde
            </h2>
            <p className="text-xl text-gray-600 mb-4">
              Ne nous croyez pas sur parole - voyez ce que disent les équipes
            </p>
            <div className="flex items-center justify-center space-x-1 mb-8">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-6 h-6 text-yellow-400 fill-current" />
              ))}
              <span className="ml-2 text-lg font-semibold text-gray-900">4.9/5 sur 2 847 avis</span>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-gradient-to-br from-white to-gray-50 p-8 rounded-2xl shadow-lg hover:shadow-xl transition-shadow border border-gray-100 hover-lift will-change-transform">
                <div className="flex items-center mb-6">
                  <img 
                    src={testimonial.avatar} 
                    alt={testimonial.name}
                    className="w-12 h-12 rounded-full mr-4 object-cover"
                    loading="lazy"
                  />
                  <div>
                    <p className="font-bold text-gray-900">{testimonial.name}</p>
                    <p className="text-gray-600 text-sm">{testimonial.role}</p>
                    <p className="text-blue-600 text-sm font-medium">{testimonial.company}</p>
                  </div>
                </div>
                <div className="flex mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-700 mb-4 italic leading-relaxed">
                  "{testimonial.content}"
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Email Signup Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-purple-600 relative overflow-hidden">
        <div className="absolute inset-0 bg-black opacity-10"></div>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="relative z-10">
            <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">
              Rejoignez 50 000+ Équipes Qui Économisent Déjà du Temps
            </h2>
            <p className="text-xl text-blue-100 mb-8">
              Recevez des conseils de productivité exclusifs, des mises à jour de fonctionnalités et des histoires de succès chaque semaine.
            </p>
            <form onSubmit={handleNewsletterSubmit} className="flex flex-col sm:flex-row gap-4 max-w-lg mx-auto mb-8">
              <div className="flex-1 relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Entrez votre email professionnel"
                  required
                  className="w-full pl-10 pr-4 py-4 rounded-xl border-0 focus:ring-4 focus:ring-blue-300 text-lg shadow-lg"
                />
              </div>
              <button 
                type="submit"
                disabled={subscribing}
                className="bg-white text-blue-600 px-8 py-4 rounded-xl font-bold hover:bg-gray-100 transition-colors disabled:opacity-50 shadow-lg text-lg hover-lift"
              >
                {subscribing ? 'Inscription...' : subscribed ? '✓ Inscrit!' : 'Conseils Gratuits →'}
              </button>
            </form>
            <p className="text-blue-200 text-sm">
              ✓ Aucun spam, jamais. ✓ Désabonnement à tout moment. ✓ 25 000+ abonnés nous font confiance.
            </p>
          </div>
        </div>
      </section>

      {/* Final CTA Section */}
      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-5xl font-bold text-gray-900 mb-6">
            Prêt à <span className="text-blue-600">Transformer</span> la Productivité de Votre Équipe?
          </h2>
          <p className="text-xl text-gray-600 mb-8">
            Rejoignez 50 000+ équipes qui économisent déjà 40% de leur temps avec AI TaskMaster
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8">
            <Link
              to="/pricing"
              className="bg-gradient-to-r from-blue-600 to-blue-700 text-white px-12 py-5 rounded-xl text-xl font-bold hover:from-blue-700 hover:to-blue-800 transition-all duration-200 flex items-center gap-2 shadow-2xl hover:shadow-3xl transform hover:-translate-y-1 hover-lift"
            >
              Essai Gratuit - Aucune Carte Bancaire Requise
              <ArrowRight className="w-6 h-6" />
            </Link>
          </div>
          <div className="flex items-center justify-center space-x-8 text-sm text-gray-500">
            <div className="flex items-center">
              <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
              Essai gratuit 14 jours
            </div>
            <div className="flex items-center">
              <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
              Aucun frais d'installation
            </div>
            <div className="flex items-center">
              <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
              Annulation à tout moment
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;